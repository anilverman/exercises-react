import AddExercise from "../components/AddExercise";

function CreateExercisePage(){
    return (
        <>
            <h2>Add Exercise</h2>
            <AddExercise></AddExercise>
        </>
    )
}

export default CreateExercisePage;